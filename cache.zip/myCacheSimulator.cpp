#include "simulator.h"
#include <cstdlib>


int main(){
    CacheSimulator myCacheSimulator;
    myCacheSimulator.run();
    return EXIT_SUCCESS;
}